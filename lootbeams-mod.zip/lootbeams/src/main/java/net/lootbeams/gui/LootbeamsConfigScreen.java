package net.lootbeams.gui;

import net.lootbeams.config.LootbeamsConfig;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

/**
 * In-game settings screen built only from vanilla widgets (no Cloth Config / Mod Menu needed).
 * Every change is written straight into LootbeamsConfig.INSTANCE (so the world updates live)
 * and saved to config/lootbeams.json when the screen closes.
 */
public class LootbeamsConfigScreen extends Screen {

    private static final String[] TAB_NAMES = {"Обводка", "Луч", "Цвета", "Предметы"};
    private static final String[] RARITY_KEYS = {"COMMON", "UNCOMMON", "RARE", "EPIC"};
    private static final String[] RARITY_LABELS = {"Обычный", "Необычный", "Редкий", "Эпический"};

    private static Text status = Text.empty();

    private final Screen parent;
    private final int tab;

    private TextFieldWidget idField;
    private TextFieldWidget colorField;

    public LootbeamsConfigScreen(Screen parent) {
        this(parent, 0);
    }

    private LootbeamsConfigScreen(Screen parent, int tab) {
        super(Text.literal("Lootbeams — настройки"));
        this.parent = parent;
        this.tab = tab;
    }

    // ---------- layout helpers ----------

    private int gx(int index) {
        return this.width / 2 - 155 + (index % 2) * 160;
    }

    private int gy(int index) {
        return 62 + (index / 2) * 24;
    }

    private static Text onOff(String label, boolean value) {
        return Text.literal(label + ": " + (value ? "ВКЛ" : "ВЫКЛ"));
    }

    private void toggle(int index, String label, BooleanSupplier getter, Consumer<Boolean> setter) {
        addDrawableChild(ButtonWidget.builder(onOff(label, getter.getAsBoolean()), b -> {
            boolean value = !getter.getAsBoolean();
            setter.accept(value);
            b.setMessage(onOff(label, value));
        }).dimensions(gx(index), gy(index), 150, 20).build());
    }

    private void slider(int index, String label, double min, double max, double current,
                        int decimals, DoubleConsumer setter) {
        addDrawableChild(new ConfigSlider(gx(index), gy(index), 150, 20, label, min, max,
                current, decimals, setter));
    }

    @Override
    protected void init() {
        LootbeamsConfig cfg = LootbeamsConfig.INSTANCE;

        // Tabs
        for (int i = 0; i < TAB_NAMES.length; i++) {
            final int target = i;
            ButtonWidget button = ButtonWidget.builder(Text.literal(TAB_NAMES[i]), b ->
                    this.client.setScreen(new LootbeamsConfigScreen(parent, target)))
                    .dimensions(this.width / 2 - 155 + i * 78, 30, 76, 20).build();
            button.active = (i != tab);
            addDrawableChild(button);
        }

        switch (tab) {
            case 0 -> {
                toggle(0, "Мод", () -> cfg.enabled, v -> cfg.enabled = v);
                slider(1, "Дистанция", 8, 128, cfg.maxRenderDistance, 0, v -> cfg.maxRenderDistance = v);
                toggle(2, "Обводка", () -> cfg.outline.enabled, v -> cfg.outline.enabled = v);
                toggle(3, "Сквозь стены", () -> cfg.outline.throughWalls, v -> cfg.outline.throughWalls = v);
                slider(4, "Толщина", 0.5, 6, cfg.outline.lineWidth, 1, v -> cfg.outline.lineWidth = (float) v);
                slider(5, "Отступ", 0, 0.5, cfg.outline.expand, 2, v -> cfg.outline.expand = (float) v);
                slider(6, "Яркость", 0.05, 1, cfg.outline.visibleAlpha, 2, v -> cfg.outline.visibleAlpha = (float) v);
                slider(7, "Яркость за стеной", 0.05, 1, cfg.outline.xrayAlpha, 2, v -> cfg.outline.xrayAlpha = (float) v);
            }
            case 1 -> {
                toggle(0, "Луч", () -> cfg.beam.enabled, v -> cfg.beam.enabled = v);
                toggle(1, "Сквозь стены", () -> cfg.beam.throughWalls, v -> cfg.beam.throughWalls = v);
                slider(2, "Ширина", 0.05, 1.5, cfg.beam.width, 2, v -> cfg.beam.width = (float) v);
                slider(3, "Высота", 1, 128, cfg.beam.height, 0, v -> cfg.beam.height = (float) v);
                slider(4, "Яркость", 0.05, 1, cfg.beam.alpha, 2, v -> cfg.beam.alpha = (float) v);
                slider(5, "Вращение (°/с)", 0, 180, cfg.beam.spinDegreesPerSecond, 0, v -> cfg.beam.spinDegreesPerSecond = (float) v);
            }
            case 2 -> {
                for (int i = 0; i < RARITY_KEYS.length; i++) {
                    final String key = RARITY_KEYS[i];
                    TextFieldWidget field = new TextFieldWidget(this.textRenderer,
                            this.width / 2 + 5, 62 + i * 26, 100, 20, Text.literal(key));
                    field.setMaxLength(7);
                    field.setText(cfg.rarityColors.getOrDefault(key, "#FFFFFF"));
                    field.setChangedListener(text -> {
                        Integer parsed = parseHex(text);
                        if (parsed != null) {
                            cfg.rarityColors.put(key, String.format("#%06X", parsed));
                        }
                    });
                    addDrawableChild(field);
                }
            }
            case 3 -> {
                idField = new TextFieldWidget(this.textRenderer, gx(0), gy(0), 150, 20, Text.literal("id"));
                idField.setMaxLength(100);
                idField.setPlaceholder(Text.literal("minecraft:diamond"));
                addDrawableChild(idField);

                colorField = new TextFieldWidget(this.textRenderer, gx(1), gy(1), 150, 20, Text.literal("color"));
                colorField.setMaxLength(7);
                colorField.setPlaceholder(Text.literal("#00FFFF"));
                addDrawableChild(colorField);

                action(2, "Задать цвет предмету", () -> {
                    Identifier id = readId();
                    Integer color = parseHex(colorField.getText());
                    if (id == null) return;
                    if (color == null) {
                        status = Text.literal("Неверный цвет, нужен формат #RRGGBB");
                        return;
                    }
                    cfg.itemColorOverrides.put(id.toString(), String.format("#%06X", color));
                    status = Text.literal("Цвет задан: " + id);
                });
                action(3, "Убрать свой цвет", () -> {
                    Identifier id = readId();
                    if (id == null) return;
                    boolean removed = cfg.itemColorOverrides.remove(id.toString()) != null;
                    status = Text.literal(removed ? "Цвет убран: " + id : "У предмета не было своего цвета");
                });
                action(4, "В чёрный список", () -> {
                    Identifier id = readId();
                    if (id == null) return;
                    cfg.blacklist.add(id.toString());
                    status = Text.literal("В чёрном списке: " + id);
                });
                action(5, "Из чёрного списка", () -> {
                    Identifier id = readId();
                    if (id == null) return;
                    cfg.blacklist.remove(id.toString());
                    status = Text.literal("Убран из чёрного списка: " + id);
                });
                action(6, "В белый список", () -> {
                    Identifier id = readId();
                    if (id == null) return;
                    cfg.whitelist.add(id.toString());
                    status = Text.literal("В белом списке: " + id);
                });
                action(7, "Из белого списка", () -> {
                    Identifier id = readId();
                    if (id == null) return;
                    cfg.whitelist.remove(id.toString());
                    status = Text.literal("Убран из белого списка: " + id);
                });
                addDrawableChild(ButtonWidget.builder(
                        onOff("Только белый список", cfg.whitelistMode), b -> {
                            cfg.whitelistMode = !cfg.whitelistMode;
                            b.setMessage(onOff("Только белый список", cfg.whitelistMode));
                        }).dimensions(this.width / 2 - 155, gy(8), 310, 20).build());
            }
            default -> {
            }
        }

        // Bottom row
        addDrawableChild(ButtonWidget.builder(Text.literal("Сбросить всё"), b -> {
            LootbeamsConfig.INSTANCE = new LootbeamsConfig();
            status = Text.literal("Настройки сброшены");
            this.client.setScreen(new LootbeamsConfigScreen(parent, tab));
        }).dimensions(this.width / 2 - 155, this.height - 28, 100, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Готово"), b -> close())
                .dimensions(this.width / 2 - 50, this.height - 28, 205, 20).build());
    }

    private void action(int index, String label, Runnable run) {
        addDrawableChild(ButtonWidget.builder(Text.literal(label), b -> run.run())
                .dimensions(gx(index), gy(index), 150, 20).build());
    }

    private Identifier readId() {
        String raw = idField.getText().trim().toLowerCase();
        Identifier id = Identifier.tryParse(raw);
        if (id == null || !Registries.ITEM.containsId(id)) {
            status = Text.literal("Неизвестный предмет: " + raw);
            return null;
        }
        return id;
    }

    private static Integer parseHex(String text) {
        String t = text.trim();
        if (t.startsWith("#")) t = t.substring(1);
        if (!t.matches("[0-9a-fA-F]{6}")) return null;
        return Integer.parseInt(t, 16);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        super.render(context, mouseX, mouseY, delta);
        context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, 12, 0xFFFFFF);

        LootbeamsConfig cfg = LootbeamsConfig.INSTANCE;
        if (tab == 2) {
            for (int i = 0; i < RARITY_KEYS.length; i++) {
                int y = 62 + i * 26;
                context.drawTextWithShadow(this.textRenderer, RARITY_LABELS[i], this.width / 2 - 155, y + 6, 0xFFFFFF);
                Integer color = parseHex(cfg.rarityColors.getOrDefault(RARITY_KEYS[i], "#FFFFFF"));
                if (color != null) {
                    context.fill(this.width / 2 + 110, y, this.width / 2 + 130, y + 20, 0xFF000000 | color);
                }
            }
            context.drawTextWithShadow(this.textRenderer, "Формат: #RRGGBB", this.width / 2 - 155, 62 + 4 * 26 + 6, 0xAAAAAA);
        } else if (tab == 3) {
            String info = "Свои цвета: " + cfg.itemColorOverrides.size()
                    + "  |  Чёрный список: " + cfg.blacklist.size()
                    + "  |  Белый: " + cfg.whitelist.size();
            context.drawCenteredTextWithShadow(this.textRenderer, info, this.width / 2, this.height - 62, 0xAAAAAA);
            context.drawCenteredTextWithShadow(this.textRenderer, status, this.width / 2, this.height - 48, 0xFFFF55);
        }
    }

    @Override
    public void close() {
        LootbeamsConfig.save();
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }

    /** Slider mapping 0..1 onto [min, max]. */
    private static class ConfigSlider extends SliderWidget {
        private final String label;
        private final double min;
        private final double max;
        private final int decimals;
        private final DoubleConsumer setter;

        ConfigSlider(int x, int y, int width, int height, String label, double min, double max,
                     double current, int decimals, DoubleConsumer setter) {
            super(x, y, width, height, Text.empty(),
                    Math.max(0, Math.min(1, (current - min) / (max - min))));
            this.label = label;
            this.min = min;
            this.max = max;
            this.decimals = decimals;
            this.setter = setter;
            updateMessage();
        }

        private double real() {
            return min + (max - min) * this.value;
        }

        @Override
        protected void updateMessage() {
            if (label == null) return; // called from super constructor before fields are set
            setMessage(Text.literal(label + ": " + String.format("%." + decimals + "f", real())));
        }

        @Override
        protected void applyValue() {
            setter.accept(real());
        }
    }
}
