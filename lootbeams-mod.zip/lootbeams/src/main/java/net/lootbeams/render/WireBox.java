package net.lootbeams.render;

import net.minecraft.client.render.VertexConsumer;
import net.minecraft.util.math.Box;
import org.joml.Matrix4f;

/**
 * Emits the 12 edges of an axis-aligned box as GL_LINES to a VertexConsumer
 * using the POSITION_COLOR_NORMAL vertex format (same format vanilla's
 * RenderLayer.LINES uses), so it's compatible with any RenderLayer built
 * from the RENDERTYPE_LINES_SNIPPET.
 */
final class WireBox {

    private WireBox() {}

    static void draw(Matrix4f pose, VertexConsumer buf, Box box, float r, float g, float b, float a) {
        float x1 = (float) box.minX, y1 = (float) box.minY, z1 = (float) box.minZ;
        float x2 = (float) box.maxX, y2 = (float) box.maxY, z2 = (float) box.maxZ;

        // Bottom face
        edge(pose, buf, x1, y1, z1, x2, y1, z1, r, g, b, a);
        edge(pose, buf, x2, y1, z1, x2, y1, z2, r, g, b, a);
        edge(pose, buf, x2, y1, z2, x1, y1, z2, r, g, b, a);
        edge(pose, buf, x1, y1, z2, x1, y1, z1, r, g, b, a);
        // Top face
        edge(pose, buf, x1, y2, z1, x2, y2, z1, r, g, b, a);
        edge(pose, buf, x2, y2, z1, x2, y2, z2, r, g, b, a);
        edge(pose, buf, x2, y2, z2, x1, y2, z2, r, g, b, a);
        edge(pose, buf, x1, y2, z2, x1, y2, z1, r, g, b, a);
        // Verticals
        edge(pose, buf, x1, y1, z1, x1, y2, z1, r, g, b, a);
        edge(pose, buf, x2, y1, z1, x2, y2, z1, r, g, b, a);
        edge(pose, buf, x2, y1, z2, x2, y2, z2, r, g, b, a);
        edge(pose, buf, x1, y1, z2, x1, y2, z2, r, g, b, a);
    }

    private static void edge(Matrix4f pose, VertexConsumer buf,
                              float x1, float y1, float z1, float x2, float y2, float z2,
                              float r, float g, float b, float a) {
        float nx = x2 - x1, ny = y2 - y1, nz = z2 - z1;
        float len = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
        if (len > 1.0e-5f) {
            nx /= len;
            ny /= len;
            nz /= len;
        }
        buf.vertex(pose, x1, y1, z1).color(r, g, b, a).normal(nx, ny, nz);
        buf.vertex(pose, x2, y2, z2).color(r, g, b, a).normal(nx, ny, nz);
    }
}
