package net.lootbeams.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.lootbeams.config.ColorResolver;
import net.lootbeams.config.LootbeamsConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.Entity;
import net.minecraft.item.ItemStack;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

import java.util.List;

/**
 * Draws a rarity-colored wireframe outline (optionally through walls) and an
 * optional vertical beam above every eligible dropped item in render range.
 *
 * Design notes on why this doesn't fight Sodium / Entity Culling / Iris:
 * - We never touch, mixin, or extend any renderer class those mods patch
 *   (ItemEntityRenderer, WorldRenderer, EntityRenderDispatcher, chunk builders, etc).
 * - We find our own items every frame via world.getEntities(), independent of the
 *   vanilla per-entity render dispatch. So even if Entity Culling decides an
 *   ItemEntity's normal model shouldn't be rendered this frame (fully occluded),
 *   our own outline/beam pass still runs, and vice versa - the two systems never
 *   call into each other.
 * - We draw with our own RenderLayers via Fabric API's WorldRenderEvents, the same
 *   officially-supported extension point Sodium itself keeps compatible.
 */
public final class ItemGlowRenderer {

    private ItemGlowRenderer() {}

    public static void onRender(WorldRenderContext context) {
        LootbeamsConfig cfg = LootbeamsConfig.INSTANCE;
        if (!cfg.enabled || (!cfg.outline.enabled && !cfg.beam.enabled)) return;

        MinecraftClient client = MinecraftClient.getInstance();
        if (client.world == null || client.player == null) return;

        Vec3d camPos = context.camera().getPos();
        MatrixStack matrices = context.matrixStack();
        if (matrices == null) return;
        VertexConsumerProvider.Immediate consumers = (VertexConsumerProvider.Immediate) context.consumers();
        if (consumers == null) return;

        double maxDistSq = cfg.maxRenderDistance * cfg.maxRenderDistance;
        long nowMs = System.currentTimeMillis();

        for (Entity entity : client.world.getEntities()) {
            if (!(entity instanceof ItemEntity itemEntity)) continue;
            if (camPos.squaredDistanceTo(entity.getPos()) > maxDistSq) continue;

            ItemStack stack = itemEntity.getStack();
            if (stack.isEmpty()) continue;

            int color = ColorResolver.resolveColorOrHide(stack);
            if (color == -1) continue;

            float r = ((color >> 16) & 0xFF) / 255f;
            float g = ((color >> 8) & 0xFF) / 255f;
            float b = (color & 0xFF) / 255f;

            // Deliberately not interpolating against the previous tick's position here:
            // dropped items barely move frame to frame, and skipping interpolation avoids
            // depending on Entity's prev-position field names, which differ across versions.
            double x = entity.getX() - camPos.x;
            double y = entity.getY() - camPos.y;
            double z = entity.getZ() - camPos.z;

            matrices.push();
            matrices.translate(x, y, z);

            if (cfg.outline.enabled) {
                Box box = entity.getBoundingBox().offset(-entity.getX(), -entity.getY(), -entity.getZ())
                        .expand(cfg.outline.expand);
                drawOutline(matrices, consumers, box, r, g, b, cfg);
            }

            if (cfg.beam.enabled) {
                float spinDeg = cfg.beam.spinDegreesPerSecond == 0f
                        ? 0f
                        : (nowMs / 1000f * cfg.beam.spinDegreesPerSecond) % 360f;
                drawBeam(matrices, consumers, r, g, b, spinDeg, cfg);
            }

            matrices.pop();
        }

        // Immediate-mode buffers must be flushed; the layers we use aren't part of
        // the vanilla "always drawn" set, so we flush explicitly at the end of the pass.
        consumers.draw(LootbeamsRenderLayers.OUTLINE_LINES_NORMAL);
        consumers.draw(LootbeamsRenderLayers.OUTLINE_LINES_XRAY);
        consumers.draw(LootbeamsRenderLayers.BEAM_QUADS_NORMAL);
        consumers.draw(LootbeamsRenderLayers.BEAM_QUADS_XRAY);
    }

    private static void drawOutline(MatrixStack matrices, VertexConsumerProvider consumers, Box box,
                                     float r, float g, float b, LootbeamsConfig cfg) {
        RenderSystem.lineWidth(cfg.outline.lineWidth);

        RenderLayer normalLayer = LootbeamsRenderLayers.OUTLINE_LINES_NORMAL;
        VertexConsumer normalBuf = consumers.getBuffer(normalLayer);
        Matrix4f pose = matrices.peek().getPositionMatrix();
        WireBox.draw(pose, normalBuf, box, r, g, b, cfg.outline.visibleAlpha);

        if (cfg.outline.throughWalls) {
            RenderLayer xrayLayer = LootbeamsRenderLayers.OUTLINE_LINES_XRAY;
            VertexConsumer xrayBuf = consumers.getBuffer(xrayLayer);
            WireBox.draw(pose, xrayBuf, box, r, g, b, cfg.outline.xrayAlpha);
        }
    }

    private static void drawBeam(MatrixStack matrices, VertexConsumerProvider consumers,
                                  float r, float g, float b, float spinDegrees, LootbeamsConfig cfg) {
        Matrix4f pose = matrices.peek().getPositionMatrix();

        VertexConsumer normalBuf = consumers.getBuffer(LootbeamsRenderLayers.BEAM_QUADS_NORMAL);
        Beam.draw(pose, normalBuf, r, g, b, cfg.beam.alpha, cfg.beam.width, cfg.beam.height, spinDegrees);

        if (cfg.beam.throughWalls) {
            VertexConsumer xrayBuf = consumers.getBuffer(LootbeamsRenderLayers.BEAM_QUADS_XRAY);
            Beam.draw(pose, xrayBuf, r, g, b, cfg.beam.alpha * 0.6f, cfg.beam.width, cfg.beam.height, spinDegrees);
        }
    }
}
