package net.lootbeams;

import com.mojang.brigadier.arguments.BoolArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.lootbeams.gui.LootbeamsConfigScreen;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import net.lootbeams.config.LootbeamsConfig;
import net.lootbeams.render.ItemGlowRenderer;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LootbeamsClient implements ClientModInitializer {

    public static final String MOD_ID = "lootbeams";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    /** Set by the /lootbeams config command; handled on the next client tick so the chat screen can't close it. */
    public static boolean openConfigRequested = false;
    private static KeyBinding openConfigKey;
    private static int autosaveTicker = 0;

    @Override
    public void onInitializeClient() {
        LootbeamsConfig.load();

        openConfigKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.lootbeams.config", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_K, "category.lootbeams"));
        // Autosave: every ~2 seconds (only writes if something changed) and again when the game closes.
        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> LootbeamsConfig.saveIfChanged());
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            if (++autosaveTicker >= 40) {
                autosaveTicker = 0;
                LootbeamsConfig.saveIfChanged();
            }
            boolean open = openConfigRequested;
            while (openConfigKey.wasPressed()) open = true;
            openConfigRequested = false;
            if (open && client.currentScreen == null) {
                client.setScreen(new LootbeamsConfigScreen(null));
            }
        });

        // AFTER_ENTITIES: fires once solid geometry + entities are drawn but before
        // translucent geometry, which is the same extension point Fabric API itself
        // documents for "draw extra stuff attached to entities/blocks". We do not
        // touch WorldRenderer, chunk building, or any entity renderer, so this cannot
        // step on Sodium's terrain/entity culling pipeline or Entity Culling's mixins.
        WorldRenderEvents.AFTER_ENTITIES.register(ItemGlowRenderer::onRender);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("lootbeams")
                        .then(ClientCommandManager.literal("config").executes(ctx -> {
                            openConfigRequested = true;
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("reload").executes(ctx -> {
                            LootbeamsConfig.load();
                            ctx.getSource().sendFeedback(Text.literal("[Lootbeams] Config reloaded."));
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("toggle")
                                .then(ClientCommandManager.argument("enabled", BoolArgumentType.bool())
                                        .executes(ctx -> {
                                            boolean value = BoolArgumentType.getBool(ctx, "enabled");
                                            LootbeamsConfig.INSTANCE.enabled = value;
                                            LootbeamsConfig.save();
                                            ctx.getSource().sendFeedback(Text.literal("[Lootbeams] Enabled: " + value));
                                            return 1;
                                        }))
                                .executes(ctx -> {
                                    LootbeamsConfig.INSTANCE.enabled = !LootbeamsConfig.INSTANCE.enabled;
                                    LootbeamsConfig.save();
                                    ctx.getSource().sendFeedback(Text.literal(
                                            "[Lootbeams] Enabled: " + LootbeamsConfig.INSTANCE.enabled));
                                    return 1;
                                }))
                )
        );

        LOGGER.info("Lootbeams initialized. Edit config/lootbeams.json to customize colors, "
                + "the outline, and the beam. Use /lootbeams reload after editing it in-game, "
                + "or /lootbeams toggle to quickly turn the whole mod on/off.");
    }
}
