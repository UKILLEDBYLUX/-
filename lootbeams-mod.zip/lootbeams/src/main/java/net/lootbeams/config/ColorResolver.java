package net.lootbeams.config;

import net.minecraft.item.ItemStack;
import net.minecraft.util.Rarity;
import net.minecraft.registry.Registries;
import net.minecraft.util.Identifier;

/**
 * Resolves the color to use for a given item stack:
 * per-item override > rarity color > white fallback.
 * Colors are cached-free on purpose (config can be hot-reloaded).
 */
public final class ColorResolver {

    private ColorResolver() {}

    /** Packed 0xRRGGBB, or -1 if this item should not be highlighted at all. */
    public static int resolveColorOrHide(ItemStack stack) {
        LootbeamsConfig cfg = LootbeamsConfig.INSTANCE;
        Identifier id = Registries.ITEM.getId(stack.getItem());
        String idStr = id.toString();

        if (cfg.whitelistMode) {
            if (!cfg.whitelist.contains(idStr)) return -1;
        } else {
            if (cfg.blacklist.contains(idStr)) return -1;
        }

        String override = cfg.itemColorOverrides.get(idStr);
        if (override != null) {
            Integer parsed = parseHex(override);
            if (parsed != null) return parsed;
        }

        String rarityName = rarityKey(stack.getRarity());
        String rarityHex = cfg.rarityColors.get(rarityName);
        if (rarityHex != null) {
            Integer parsed = parseHex(rarityHex);
            if (parsed != null) return parsed;
        }

        return 0xFFFFFF;
    }

    /**
     * Rarity stopped being a plain Java enum in recent Minecraft versions, so we compare
     * by identity against the vanilla constants rather than trust toString()/name().
     * Anything that isn't one of the four vanilla constants (e.g. a datapack-added
     * rarity) falls back to the COMMON color unless the pack author adds it to
     * rarityColors under its own key.
     */
    private static String rarityKey(Rarity rarity) {
        if (rarity == Rarity.EPIC) return "EPIC";
        if (rarity == Rarity.RARE) return "RARE";
        if (rarity == Rarity.UNCOMMON) return "UNCOMMON";
        return "COMMON";
    }

    private static Integer parseHex(String hex) {
        try {
            String cleaned = hex.startsWith("#") ? hex.substring(1) : hex;
            return Integer.parseInt(cleaned, 16) & 0xFFFFFF;
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
