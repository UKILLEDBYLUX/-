# Lootbeams

Fabric mod for Minecraft **1.21.4**. Highlights every dropped item on the ground with:

- a **wireframe outline** colored by the item's rarity (or a per-item override), visible
  through walls;
- an optional **vertical beam** above the item, same color, also visible through walls;
- a **JSON config** (`config/lootbeams.json`) for colors, distances, alpha, line width,
  beam size, and a whitelist/blacklist of item IDs;
- `/lootbeams reload` and `/lootbeams toggle [true|false]` client commands.

## Why it shouldn't conflict with Sodium / Entity Culling / Iris

This mod contains **zero mixins** and doesn't touch `WorldRenderer`, chunk building,
`ItemEntityRenderer`, or `EntityRenderDispatcher` - all the classes those performance
mods hook into. Instead it:

1. Uses Fabric API's public `WorldRenderEvents.AFTER_ENTITIES` event (an official,
   Sodium-compatible extension point).
2. Finds dropped items itself every frame via `world.getEntities(...)`, independent of
   the vanilla per-entity render dispatch - so it doesn't matter whether Entity Culling
   decides to skip an item's normal model this frame; the outline pass runs regardless.
3. Draws with its own custom `RenderLayer`s, never replacing or wrapping a vanilla one.

That said, "shouldn't conflict" isn't the same as "tested against every combination of
mods and versions" - please test in your actual modpack before shipping it.

## Building

1. Install a JDK 21.
2. Open `gradle.properties` and double-check `minecraft_version`, `yarn_mappings`,
   `loader_version`, and `fabric_version` against <https://fabricmc.net/develop> -
   these strings change often and are the #1 cause of a failed first Gradle sync.
3. `./gradlew build` (or open the folder in IntelliJ IDEA with the Fabric/Gradle
   plugins and let it import). The built jar lands in `build/libs/`.
4. Drop the jar, plus **Fabric API** and **Fabric Loader** matching your Minecraft
   version, into your `mods` folder.

There's no Gradle wrapper jar included (binary files don't travel well through this
chat) - either run `gradle wrapper` once you have any Gradle installed, or use the
wrapper from the official Fabric example mod template as a starting point and copy
these sources over it.

## A note on the rendering code specifically

Minecraft rewrote its low-level rendering internals (`RenderPipeline`,
`DepthTestFunction`, etc., replacing the older `RenderPhase`-only system) in 1.21.2,
and it has kept shifting in small ways release to release. The custom "see through
walls" `RenderLayer`s live in `render/LootbeamsRenderLayers.java`, isolated from the
rest of the mod specifically so that if your exact build's mappings renamed a snippet
(`RenderPipelines.RENDERTYPE_LINES_SNIPPET`, `RenderPipelines.MATRICES_COLOR_SNIPPET`)
or a builder method, you only have one file to patch. If it doesn't compile out of the
box:

1. Open `RenderLayer.LINES` in your decompiled sources (Loom → "Generate Sources") and
   copy however *it* builds its pipeline for your exact build.
2. Do the same for any vanilla untextured/translucent quad layer (search for a
   `RenderLayer` built from a `MATRICES_COLOR` or `POSITION_COLOR` snippet) as a
   reference for the beam pipeline.
3. If beams render fully opaque instead of fading out, your build's
   `MATRICES_COLOR_SNIPPET` may not carry a blend function by default - add an explicit
   `.withBlendFunction(...)` call (check `com.mojang.blaze3d.pipeline.BlendFunction`
   for the available presets in your mappings) to `BEAM_NORMAL_PIPELINE` /
   `BEAM_XRAY_PIPELINE`.

Everything else (config loading, item filtering, color resolution, the command) uses
stable, long-standing APIs and shouldn't need any of that.

## Configuring (`config/lootbeams.json`)

Generated on first launch. Example:

```json
{
  "enabled": true,
  "maxRenderDistance": 48.0,
  "outline": {
    "enabled": true,
    "throughWalls": true,
    "lineWidth": 1.5,
    "expand": 0.05,
    "visibleAlpha": 1.0,
    "xrayAlpha": 0.35
  },
  "beam": {
    "enabled": true,
    "throughWalls": true,
    "width": 0.25,
    "height": 60.0,
    "alpha": 0.5,
    "spinDegreesPerSecond": 20.0
  },
  "rarityColors": {
    "COMMON": "#FFFFFF",
    "UNCOMMON": "#FFFF55",
    "RARE": "#55FFFF",
    "EPIC": "#FF55FF"
  },
  "itemColorOverrides": {
    "minecraft:netherite_ingot": "#B24544",
    "minecraft:diamond": "#4DE6E0",
    "minecraft:nether_star": "#FFD966"
  },
  "whitelistMode": false,
  "whitelist": [],
  "blacklist": ["minecraft:arrow", "minecraft:snowball", "minecraft:egg", "minecraft:experience_bottle"]
}
```

- **`itemColorOverrides`** always wins over `rarityColors` for a given item.
- Set **`whitelistMode: true`** to flip from "highlight everything except
  `blacklist`" to "highlight only what's in `whitelist`".
- `xrayAlpha` / beam's `alpha * 0.6` control how visible the through-wall portion is;
  set `throughWalls: false` on either effect to disable x-ray for just that effect
  (fully vanilla-style occlusion instead).
- After hand-editing the file while the game is running, run `/lootbeams reload`.

## Known limitations / ideas for follow-up

- No in-game config GUI (kept out on purpose to avoid pulling in a config-library
  dependency that could itself become a source of conflicts). Cloth Config + a mod
  menu integration would be a natural add-on.
- Beam is drawn as four crossed quads (cheap, no texture) rather than a textured
  cylinder like the vanilla beacon beam - visually simpler but trivially fast and
  won't stress Sodium's batching.
- No per-dimension or per-biome rules; `blacklist`/`whitelist` are global.
